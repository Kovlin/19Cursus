from django.db import models
from django import forms

class PostImage(models.Model):
	title = models.CharField(max_length=64, null=False)
	image = models.ImageField(upload_to="media/", null=False)