from django.shortcuts import render, redirect
from .forms import ImageForm
from .models import PostImage

# Create your views here.

def index(request):
	if request.method == 'POST':
		f = ImageForm(request.POST, request.FILES)
		if f.is_valid():
			f.save()
		else:
			print(f.errors)
		return redirect("/")
	form = ImageForm()
	gallery = PostImage.objects.all()
	return render(request, "ex00/index.html", {'form': form, 'gallery': gallery})