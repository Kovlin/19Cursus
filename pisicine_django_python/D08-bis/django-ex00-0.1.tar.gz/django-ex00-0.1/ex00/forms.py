from .models import PostImage
from django import forms

class ImageForm(forms.ModelForm):
	class Meta:
		model = PostImage
		fields = ['title', 'image']